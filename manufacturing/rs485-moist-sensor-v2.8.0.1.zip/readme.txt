Chirp! soil moisture sensor v2.7.8

Order qty: 500

Contact: Albertas Mickenas, albertas@technariumas.lt, +37062684638

Shipping address:

Albertas Mickenas, Technariumas
phone no: +37062684638
Aguonu 17
LT-03012 Vilnius
Lithuania

PCB specification: FR4, 1.6mm, 35um copper, Black soldermask, HASL lead free, 
Lead free solder
