Chirp! soil moisture sensor v2.7.8

Order qty: 300

Contact: Albertas Mickenas, albertas@technariumas.lt, +37062684638

Shipping address:

Albertas Mickenas, Technariumas
phone no: +37062684638
Pramones 141 - 4
LT-11115 Vilnius
Lithuania

PCB specification: 4 layers, FR4, 1.6mm, 35um copper, Matt black soldermask, White silkscreen, HASL lead free, 
Lead free solder
